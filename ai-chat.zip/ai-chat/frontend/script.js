async function sendMessage() {
  const input = document.getElementById("msg");
  const chatBox = document.getElementById("chatBox");

  const message = input.value.trim();
  if (!message) return;

  // user message
  const userDiv = document.createElement("div");
  userDiv.className = "msg user";
  userDiv.innerText = message;
  chatBox.appendChild(userDiv);

  input.value = "";
  chatBox.scrollTop = chatBox.scrollHeight;

  // loading
  const loading = document.createElement("div");
  loading.className = "msg bot";
  loading.innerText = "Typing...";
  chatBox.appendChild(loading);

  try {
    const res = await fetch("http://localhost:3000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });

    const data = await res.json();

    loading.remove();

    const botDiv = document.createElement("div");
    botDiv.className = "msg bot";
    botDiv.innerText = data.reply;

    chatBox.appendChild(botDiv);
    chatBox.scrollTop = chatBox.scrollHeight;

  } catch (err) {
    loading.remove();

    const errorDiv = document.createElement("div");
    errorDiv.className = "msg bot";
    errorDiv.innerText = "Error connecting to server";

    chatBox.appendChild(errorDiv);
  }
}